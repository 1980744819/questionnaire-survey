<!DOCTYPE html>
<html>
<head>
<title>主页</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
welcome<br>
<?php
       echo $_COOKIE["username"];
?>
</body>
</html>